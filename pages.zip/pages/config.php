<?php
// Database configuration
$host = "localhost";
$username = "root";
//$password = "6C7VpCjhDDb8";
$password = "";
$database = "airqo";

// Establish the database connection
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Other configuration variables
$siteName = "Your Web App";
$adminEmail = "admin@example.com";
?>




