<?php

include 'config.php';


    // Handle form input values
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
    } else {
        // Handle the error condition when batchNo is not set
        echo "Error: id is not set.";
        exit();
    }

    if (isset($_POST['item'])) {
        $datetime = $_POST['item'];
    } else {
        // Handle the error condition when datetime is not set
        echo "Error: Datetime is not set.";
        exit();
    }

    if (isset($_POST['stockin'])) {
        $qty = $_POST['stockin'];
    } else {
        // Handle the error condition when qty is not set
        echo "Error: Quantity is not set.";
        exit();
    }

    if (isset($_POST['datetime'])) {
        $eventdetail = $_POST['datetime'];
    } else {
        // Handle the error condition when eventdetail is not set
        echo "Error: Event Detail is not set.";
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO $inventory (id, item, stockin, datetime) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $id, $datetime, $qty, $datetime);
    $execval = $stmt->execute();

    if ($execval) {
        // Successful insertion, redirect to index.php
        header('Location: stocktake.php');
        exit();
    } else {
        // Handle the error
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

?>
